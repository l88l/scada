#!/bin/sh
sudo service scadaserver start

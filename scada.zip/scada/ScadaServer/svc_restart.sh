#!/bin/sh
sudo service scadaserver stop
sudo service scadaserver start

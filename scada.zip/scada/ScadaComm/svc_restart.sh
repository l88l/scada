#!/bin/sh
sudo service scadacomm stop
sudo service scadacomm start

#!/bin/sh
sudo chmod +x /opt/scada/restart_apache.sh
sudo chmod +x /opt/scada/scadarestart.sh
sudo chmod +x /opt/scada/scadastart.sh
sudo chmod +x /opt/scada/scadastop.sh
sudo chmod +x /opt/scada/svc_install.sh
sudo chmod +x /opt/scada/svc_uninstall.sh
sudo chmod +x /opt/scada/ScadaAgent/svc_restart.sh
sudo chmod +x /opt/scada/ScadaAgent/svc_start.sh
sudo chmod +x /opt/scada/ScadaAgent/svc_stop.sh
sudo chmod +x /opt/scada/ScadaComm/svc_restart.sh
sudo chmod +x /opt/scada/ScadaComm/svc_start.sh
sudo chmod +x /opt/scada/ScadaComm/svc_stop.sh
sudo chmod +x /opt/scada/ScadaServer/svc_restart.sh
sudo chmod +x /opt/scada/ScadaServer/svc_start.sh
sudo chmod +x /opt/scada/ScadaServer/svc_stop.sh

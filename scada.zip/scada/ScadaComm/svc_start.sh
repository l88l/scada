#!/bin/sh
sudo service scadacomm start

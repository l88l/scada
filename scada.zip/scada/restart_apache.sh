#!/bin/sh
sudo service apache2 restart

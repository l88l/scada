#!/bin/sh
sudo service scadaagent stop
sudo service scadaagent start

#!/bin/sh
sudo service scadaagent stop

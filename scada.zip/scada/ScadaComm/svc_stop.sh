#!/bin/sh
sudo service scadacomm stop

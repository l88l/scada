#!/bin/sh
sudo service scadaserver stop

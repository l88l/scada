#!/bin/sh
sudo service scadaagent start
